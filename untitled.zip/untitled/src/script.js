const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");


if (menuToggle && navLinks) {

  menuToggle.addEventListener(
    "click",
    function () {

      navLinks.classList.toggle("active");

    }
  );

}


document
  .querySelectorAll(".nav-links a")
  .forEach(function (link) {

    link.addEventListener(
      "click",
      function () {

        if (navLinks) {
          navLinks.classList.remove("active");
        }

      }
    );

  });




const questions =
  document.querySelectorAll(".faq-question");


questions.forEach(function (question) {

  question.addEventListener(
    "click",
    function () {

      const currentItem =
        question.parentElement;


      document
        .querySelectorAll(".faq-item")
        .forEach(function (item) {

          if (item !== currentItem) {
            item.classList.remove("active");
          }

        });


      currentItem.classList.toggle("active");

    }
  );

});




const donuts = [

  {
    name: "Classic Glazed",
    price: "₱20",
    className: "classic"
  },

  {
    name: "Chocolate",
    price: "₱20",
    className: "chocolate"
  },

  {
    name: "Strawberry",
    price: "₱30",
    className: "strawberry"
  },

  {
    name: "Ube",
    price: "₱30",
    className: "ube"
  },

  {
    name: "Special Glazed",
    price: "₱28",
    className: "special"
  },

  {
    name: "Cookies & Cream",
    price: "₱30",
    className: "cookies"
  },

  {
    name: "Choco Nuts",
    price: "₱32",
    className: "choco-nuts"
  },

  {
    name: "Berry Filled",
    price: "₱30",
    className: "berry"
  }

];




const pickButton =
  document.getElementById("pickDonut");


const donutVisual =
  document.getElementById(
    "selectedDonutVisual"
  );


const donutName =
  document.getElementById(
    "selectedDonutName"
  );


const donutPrice =
  document.getElementById(
    "selectedDonutPrice"
  );




if (
  pickButton &&
  donutVisual &&
  donutName &&
  donutPrice
) {

  pickButton.addEventListener(
    "click",
    function () {

      const randomIndex =
        Math.floor(
          Math.random() * donuts.length
        );


      const selectedDonut =
        donuts[randomIndex];


      donutVisual.style.transform =
        "rotate(720deg) scale(0.8)";


      setTimeout(
        function () {

          donutVisual.className =
            "picker-donut " +
            selectedDonut.className;


          donutVisual.innerHTML =
            '<div class="small-hole"></div>';


          donutName.textContent =
            selectedDonut.name;


          donutPrice.textContent =
            selectedDonut.price;


          donutVisual.style.transform =
            "rotate(0deg) scale(1)";

        },
        400
      );


      pickButton.textContent =
        "CHOOSING...";


      setTimeout(
        function () {

          pickButton.textContent =
            "PICK AGAIN!";

        },
        1000
      );

    }
  );

}